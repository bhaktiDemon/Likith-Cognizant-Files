package OnlineMobileSearch;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class driverSetup {

	static WebDriver driver;
	
	static String url = "https://www.amazon.in/";
	
	public static WebDriver createDriver(String name) {
		
		if(name.equalsIgnoreCase("chrome")) {
			
			driver = new ChromeDriver();
			
		}else if(name.equalsIgnoreCase("edge")) {
			
			driver = new EdgeDriver();
			
		}
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get(url);
		driver.manage().window().maximize();
		
		return driver;
		
	}
	
	public static void quitDriver() {
		System.out.println("Closing the driver");
		driver.quit();
	}
	
	
	
	
	
}
