package OnlineMobileSearch;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;


public class ScreenShot {
	
	public static void screenShot(String imagePath) throws IOException {
		
		System.out.println("Taking Screenshot...");
		
		TakesScreenshot ts = (TakesScreenshot)driverSetup.driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		File target = new File(imagePath);
		
		FileUtils.copyFile(source, target);
		
	}
	
}
