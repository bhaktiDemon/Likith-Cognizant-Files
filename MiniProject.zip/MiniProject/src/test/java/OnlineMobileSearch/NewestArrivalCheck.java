package OnlineMobileSearch;

public class NewestArrivalCheck {
	
	public static void newestArrivalValidate(String actualOption) {
		
		String expectedOption = "Newest Arrivals";
		
		
		if(actualOption.equals(expectedOption)) {
			System.out.println("Newest Arrivals option got selected correctly");
		}else {
			System.out.println("Newest Arrivals option did not get selected correctly");
		}
		
	}
	
}
