package OnlineMobileSearch;

public class SearchStringValidation {
	
	public static String numberOfItem(String str) {

		String[] strNew = str.split(" ");
		
		// validating the item number
		String pageNo[] = strNew[0].split("-");
		int itemStartNo = Integer.parseInt(pageNo[0]);
		int itemLastNo = Integer.parseInt(pageNo[1]);
		
		if(itemStartNo > 0 && itemLastNo > itemStartNo ) {
			System.out.println("Item Number : "+strNew[0]);
		}
		
		return strNew[0]; 
		
	}
	
	public static String itemCount(String str) {
		
		String[] strNew = str.split(" ");
		
		String itemCount = strNew[3].replace(",", "");
		int itemCountNew = Integer.parseInt(itemCount);
				
		if(itemCountNew > 0) {
			System.out.println("Item Count : "+itemCountNew);
		}
		
		return itemCount;
		
	}
	
	public static String stringValidation(String actualSearchString) {
		
		String result;
		
		String expectedSearchString = "mobile smartphones under 30000";
		
		if(actualSearchString.equals(expectedSearchString)) {
			System.out.println("Search string validation : Pass");
			result = "Pass";
		}else {
			System.out.println("Search string validation : Failed");
			result = "False";
		}
		
		return result;
	
	}
	
	
}
