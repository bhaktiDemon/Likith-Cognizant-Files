package OnlineMobileSearch;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class WritingIntoExcel {

	public static void writeData(String itemNo, String itemCount, String stringValidation, int listSize) throws IOException {
		
		
		System.out.println("Writing into the excel...");
		
		FileOutputStream file = new FileOutputStream(System.getProperty("user.dir")+"\\testdata\\amazon.xlsx");
		
		XSSFWorkbook workbook = new XSSFWorkbook();
		
		XSSFSheet sheet = workbook.createSheet();
		
		XSSFRow row1 = sheet.createRow(0);
		row1.createCell(0).setCellValue("itemNo");
		row1.createCell(1).setCellValue(itemNo);
		
		XSSFRow row2 = sheet.createRow(1);
		row2.createCell(0).setCellValue("itemCount");
		row2.createCell(1).setCellValue(itemCount);

		XSSFRow row3 = sheet.createRow(2);
		row3.createCell(0).setCellValue("stringValidation");
		row3.createCell(1).setCellValue(stringValidation);
		
		XSSFRow row4 = sheet.createRow(3);
		row4.createCell(0).setCellValue("SizeOfListBox");
		row4.createCell(1).setCellValue(listSize);
		
		
		workbook.write(file);
		workbook.close();
		file.close();
		
	}
	
}
