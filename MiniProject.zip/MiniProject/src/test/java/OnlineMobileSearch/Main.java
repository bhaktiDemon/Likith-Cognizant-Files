package OnlineMobileSearch;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Main {
	public static void main(String[] args) throws IOException {
		
		
		// Calling the driver setup method
		driverSetup.createDriver("Chrome");
		WebDriver driver = driverSetup.driver;
		
		// Fetching the title of the landing page
		System.out.println(driver.getTitle());
		
		System.out.println();
		System.out.println("--------------------");
		System.out.println();
		
		// Locating the search box and then entering the text
		WebElement search =  driver.findElement(By.id("twotabsearchtextbox"));
		search.sendKeys("mobile smartphones under 30000");
		
		//clicking on the search button
		driver.findElement(By.id("nav-search-submit-button")).click();
		
		// validation of string
		String str1 = driver.findElement(By.xpath("//div[@class='a-section a-spacing-small a-spacing-top-small']/span[1]")).getText();
		String noOfItem = SearchStringValidation.numberOfItem(str1);
//		System.out.println(noOfItem);
		
		System.out.println();
		System.out.println("--------------------");
		System.out.println();
		
		// Validation of total item count
		String itemCount = SearchStringValidation.itemCount(str1);
		
		System.out.println();
		System.out.println("--------------------");
		System.out.println();
		
		// validating the search string
		String actualSearchString = driver.findElement(By.xpath("//span[@class='a-color-state a-text-bold']")).getText().replace("\"", "");
		String stringValidation = SearchStringValidation.stringValidation(actualSearchString);
		
		System.out.println();
		System.out.println("--------------------");
		System.out.println();

		// Clicking on sort by list box
		driver.findElement(By.className("a-button-text")).click();
		
		// Validation of the list box options
		List<WebElement> list = driver.findElements(By.xpath("//div[@class='a-popover-inner']//li")); 
		for(WebElement e : list) {
			System.out.println(e.getText());
		}
		
		System.out.println();
		System.out.println("--------------------");
		System.out.println();

		// printing the size of the drop down
		int listSize = list.size();
		System.out.println("Size of list box "+listSize);
		
		System.out.println();
		System.out.println("--------------------");
		System.out.println();
		
		//selecting Newest arrivals from the list box
		driver.findElement(By.id("s-result-sort-select_4")).click();
		
		// Validating if newest arrival option is selected or not 
		String actualOption = driver.findElement(By.xpath("//span[@id='a-autoid-24-announce']/span[2]")).getText();
		NewestArrivalCheck.newestArrivalValidate(actualOption);
		
		System.out.println();
		System.out.println("--------------------");
		System.out.println();
		
		// writing into excel
//		String demo = SeaarchStringValidation.numberOfItem(str1);
		WritingIntoExcel.writeData(noOfItem, itemCount, stringValidation, listSize);
		
		System.out.println();
		System.out.println("--------------------");
		System.out.println();
		
		// Taking Screenshot
		String imagePath = "C:\\Users\\2332843\\OneDrive - Cognizant\\Desktop\\Java\\JavaDumps\\MiniProject\\Screenshots\\final.png";
		ScreenShot.screenShot(imagePath);
		
		System.out.println();
		System.out.println("--------------------");
		System.out.println();
		
		// quit the browser
		driverSetup.quitDriver();
		
	}
}
