package Amazon;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class OnlineMobileSearch {

	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();
		
		// Implicit wait
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		// Opening the Web site
		driver.get("https://www.amazon.in/");
		driver.manage().window().maximize();
		
		// get title
		System.out.println(driver.getTitle());
		
		System.out.println();
		System.out.println("--------------------------------------");
		System.out.println();
		
		// Locating the search box and then entering the text
		WebElement search =  driver.findElement(By.id("twotabsearchtextbox"));
		search.sendKeys("mobile smartphones under 30000");
		
		//clicking on the search button
		driver.findElement(By.id("nav-search-submit-button")).click();
		
		// validation of string
		String str = driver.findElement(By.xpath("//div[@class='a-section a-spacing-small a-spacing-top-small']/span[1]")).getText();
		String[] strNew = str.split(" ");
		
		// validating the page count
		String pageNo[] = strNew[0].split("-");
		int startPageNo = Integer.parseInt(pageNo[0]);
		int lastPageNo = Integer.parseInt(pageNo[1]);	
		
		if(startPageNo > 0 && lastPageNo > startPageNo ) {
			System.out.println("Page Number : "+strNew[0]);
		}
		
		// validating the item count
		String itemCount = strNew[3].replace(",", "");
		int itemCountNew = Integer.parseInt(itemCount);
		
		if(itemCountNew > 0) {
			System.out.println("Item Count : "+itemCountNew);
		}
		
		System.out.println();
		System.out.println("--------------------------------------");
		System.out.println();
		
		// validating the search string
		String s1 = driver.findElement(By.xpath("//span[@class='a-color-state a-text-bold']")).getText().replace("\"", "");
//		System.out.println(s1);
		String s2 = "mobile smartphones under 30000";
		
		if(s1.equals(s2)) {
			System.out.println("Search string validation : Pass");
		}else {
			System.out.println("Search string validation : Failed");
		}
		
		System.out.println();
		System.out.println("--------------------------------------");
		System.out.println();
		
	
		// Clicking on sort by list box
		driver.findElement(By.className("a-button-text")).click();
		
		// Validation of the list box options
		List<WebElement> list = driver.findElements(By.xpath("//*[@id=\"a-popover-2\"]/div/div/ul/li[@class=\"a-dropdown-item\"]")); 
		
		for(WebElement e : list) {
			System.out.println(e.getText());

		}
		System.out.println();
		System.out.println("--------------------------------------");
		System.out.println();
		
		System.out.println("Size of list box "+list.size());
		System.out.println();
		System.out.println("--------------------------------------");
		System.out.println();
		
		//selecting Newest arrivals from the list box
		driver.findElement(By.id("s-result-sort-select_4")).click();
		
		String l1 = driver.findElement(By.xpath("//span[@class='a-button-text a-declarative']/span[2]")).getText();
		String l2 = "Newest Arrivals";
		
		
		if(l1.equals(l2)) {
			System.out.println("Newest Arrivals option got selected correctly");
		}else {
			System.out.println("Newest Arrivals option did not get selected correctly");
		}
		System.out.println();
		System.out.println("--------------------------------------");
		System.out.println();
		
		System.out.println("Closing the driver");

				
		driver.quit();
		
		
		
	}

}
